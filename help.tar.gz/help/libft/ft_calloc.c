/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_calloc.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: haeris <haeris@student.42istanbul.com.t    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/12 10:07:03 by haeris            #+#    #+#             */
/*   Updated: 2023/05/12 10:07:05 by haeris           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_calloc(size_t x, size_t size)
{
	void	*str;
	size_t	total;

	total = size * x;
	str = malloc(total);
	if (!str)
		return (0);
	while (total != 0)
	{
		((unsigned char *)str)[total - 1] = 0;
		total--;
	}
	return (str);
}
