/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strdup.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: haeris <haeris@student.42istanbul.com.t    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/12 10:09:35 by haeris            #+#    #+#             */
/*   Updated: 2023/05/12 10:09:37 by haeris           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strdup(const char *s)
{
	char	*s2;
	size_t	i;
	size_t	j;

	j = 0;
	i = ft_strlen(s) + 1;
	s2 = (char *)malloc(sizeof(char) * i);
	if (!s || !s2)
		return (0);
	while (i > j)
	{
		((unsigned char *)s2)[j] = ((unsigned char *)s)[j];
		j++;
	}
	return (s2);
}
