/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: haeris <haeris@student.42istanbul.com.t    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/12 10:09:52 by haeris            #+#    #+#             */
/*   Updated: 2023/05/12 10:09:58 by haeris           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dst, const char *src, size_t size)
{
	size_t	i;
	size_t	len;

	len = ft_strlen(dst);
	i = 0;
	if (len >= size)
		return (size + ft_strlen(src));
	while (src[i] != 0 && len < size - 1)
	{
		dst[len] = src[i];
		i++;
		len++;
	}
	dst[len] = 0;
	return (ft_strlen(dst) + ft_strlen(&src[i]));
}
