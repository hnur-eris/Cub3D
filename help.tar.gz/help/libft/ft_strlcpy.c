/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: haeris <haeris@student.42istanbul.com.t    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/05/12 10:10:09 by haeris            #+#    #+#             */
/*   Updated: 2023/05/12 10:10:10 by haeris           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcpy(char *dst, const char *src, size_t dstsize)
{
	size_t	srcsize;
	size_t	j;

	j = 0;
	srcsize = 0;
	if (!dstsize)
		return (ft_strlen(src));
	srcsize = ft_strlen(src);
	if (dstsize != 0)
	{
		while (j < dstsize - 1 && src[j])
		{
			((char *)dst)[j] = ((const char *)src)[j];
			j++;
		}
		dst[j] = '\0';
	}
	return (srcsize);
}
